
using UnityEngine;

public class OthersGunsChange : MonoBehaviour
{

    private string currentGunName = null;
    public void ChangeGun(string gunName)
    {
        if (currentGunName != null)
        {
            GameObject.Find(currentGunName).SetActive(false);
        }
        currentGunName = gunName;
        GameObject.Find(gunName).SetActive(true);
    }
}
